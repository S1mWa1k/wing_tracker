function row = polygonToRow(polygon, varargin)
%POLYGONTOROW Create a polygon from a row vector
%
%   ROW = polygonToRow(POLY);
%   where POLY is a Nx2 array of points representing vertices of the
%   polygon, converts the vertex coordinates into a linear array:
%   ROW = [X1 Y1 X2 Y2 .... XN YN]
%
%   ROW = polygonToRow(POLY, TYPE);
%   Can coose another format for converting polygon. Possibilities are:
%   'interlaced' (default}, as described above
%   'packed': ROW has format [X1 X2 ... XN Y1 Y2 ... YN].
%
%   Example
%   polygonToRow
%
%   See also
%   polygons2d, rowToPolygon
%
%
% ------
% Author: David Legland
% e-mail: david.legland@grignon.inra.fr
% Created: 2010-07-23,    using Matlab 7.9.0.529 (R2009b)
% Copyright 2010 INRA - Cepia Software Platform.

type = 'interlaced';
if ~isempty(varargin)
    type = varargin{1};
end


if strcmp(type, 'interlaced')
    Np = size(polygon, 1);
    row = reshape(polygon', [1 2*Np]);
elseif strcmp(type, 'packed')
    row = polygon(:)';
end
