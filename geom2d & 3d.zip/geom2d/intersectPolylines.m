function pts = intersectPolylines(poly1, varargin)
%INTERSECTPOLYLINES  find common points between 2 polylines
%   output = intersectPolylines(input)
%
%   Example
%   intersectPolylines
%
%   See also
%
%
% ------
% Author: David Legland
% e-mail: david.legland@grignon.inra.fr
% Created: 2009-06-15,    using Matlab 7.7.0.471 (R2008b)
% Copyright 2009 INRA - Cepia Software Platform.
% Licensed under the terms of the LGPL, see the file "license.txt"

if isempty(varargin)
    pts = interX(poly1')';
else
    pts = interX(poly1', varargin{1}');
end