function vectors3d(varargin)
%VECTORS3D  description of functions operating on 3D vectors
%
%   Vectors are represented by their 3 Cartesian coordinates:
%   V = [VX VY VZ];
%
%   list of vectors are represented by N*3 arrays.
%
%
%   See also
%   vectorNorm3d, normalizeVector3d
%   isParallel3d, isPerpendicular3d
%   createTranslation3d
%
% ------
% Author: David Legland
% e-mail: david.legland@nantes.inra.fr
% Created: 2008-10-13,    using Matlab 7.4.0.287 (R2007a)
% Copyright 2008 INRA - BIA PV Nantes - MIAJ Jouy-en-Josas.
