function varargout = createSoccerBall()
%CREATESOCCERBALL Create a 3D mesh representing a soccer ball
%
%   It is basically a wrapper of the 'bucky' function in matlab.
%   [v e f] = createSoccerBall
%   return vertices, edges and faces that constitute a soccerball
%
%   Example
%   [v f] = createSoccerBall;
%   drawMesh(v, f);
%
%   See also
%   meshes, drawMesh, bucky
%
%
% ------
% Author: David Legland
% e-mail: david.legland@jouy.inra.fr
% Created: 2006-08-09
% Copyright 2006 INRA - CEPIA Nantes - MIAJ (Jouy-en-Josas).

%   HISTORY
%   04/01/2007: remove unused variables, enhance output processing

% get vertices and edges of the buckyball
[b n] = bucky;
[i j] = find(b);
e = [i j];

% compute polygons that correspond to each 3D face
f = minConvexHull(n);

% format output
if nargout==0 || nargout==3
    varargout{1} = n;
    varargout{2} = e;
    varargout{3} = f;
elseif nargout==2
    varargout{1} = n;
    varargout{2} = f;
elseif nargout==1
    % return a structure
    s.nodes = n;
    s.edges = e;
    s.faces = f;
    varargout{1} = s;
end
