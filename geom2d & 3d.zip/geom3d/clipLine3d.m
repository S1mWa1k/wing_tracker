function edge = clipLine3d(line, box)
%CLIPLINE3D clip a line with a box and return an edge
%
%   EDGE = clipLine3d(LINE, BOX);
%   Clips the line LINE with the bounds given in BOX, and returns the
%   corresponding edge.
%
%   See also:
%   lines3d, createLine3d
%
%   ---------
%   author : David Legland 
%   INRA - TPV URPOI - BIA IMASTE
%   created the 30/10/2008 from drawLine3d

%   HISTORY
%   30/10/2008 replace intersectPlaneLine by intersectLinePlane
%   25/11/2008 improve test for bounds, and use more explicit code
%   22/06/2009 fig bug, add support for several lines

% get box limits
xmin = box(1); xmax = box(2);
ymin = box(3); ymax = box(4);
zmin = box(5); zmax = box(6);

% extreme corners of the box
p000 = [xmin ymin zmin];
p111 = [xmax ymax zmax];

% main vectors
ex   = [1 0 0];
ey   = [0 1 0];
ez   = [0 0 1];

% box faces parallel to Oxy
planeZ0 = [p000 ex ey];
planeZ1 = [p111 ex ey];

% box faces parallel to Oxz
planeY0 = [p000 ex ez];
planeY1 = [p111 ex ez];

% box faces parallel to Oyz
planeX0 = [p000 ey ez];
planeX1 = [p111 ey ez];

% number of lines
Nl = size(line, 1);

% allocate memory for result
edge = zeros(Nl, 6);


% process each line
for i=1:Nl
    
    % compute intersection point with each plane
    ipZ0 = intersectLinePlane(line(i,:), planeZ0);
    ipZ1 = intersectLinePlane(line(i,:), planeZ1);
    ipY0 = intersectLinePlane(line(i,:), planeY0);
    ipY1 = intersectLinePlane(line(i,:), planeY1);
    ipX1 = intersectLinePlane(line(i,:), planeX1);
    ipX0 = intersectLinePlane(line(i,:), planeX0);

    % concatenate resulting points
    points  = [ipX0;ipX1;ipY0;ipY1;ipZ0;ipZ1];

    % compute position of each point on the line
    pos     = linePosition3d(points, line(i,:));

    % keep only defined points
    ind     = find(~isnan(pos));
    pos     = pos(ind);
    points  = points(ind,:);

    % sort points with respect to their position
    [pos ind] = sort(pos);
    points  = points(ind, :);

    % keep median points wrt to position. These points define the limit of the
    % clipped edge.
    nv      = length(ind)/2;

    % create resulting edge.
    edge(i,:)   = [points(nv, :) points(nv+1, :)];
end


% check if the clipped edge is located inside of the bounding box or not.
x1      = edge(:,1);
y1      = edge(:,2);
z1      = edge(:,3);
x2      = edge(:,4); 
y2      = edge(:,5); 
z2      = edge(:,6);
eps     = 1e-14;

% check bounds of result edge in each direction
xOk     = xmin-min(x1,x2)<eps & max(x1,x2)-xmax<eps;
yOk     = ymin-min(y1,y2)<eps & max(y1,y2)-ymax<eps;
zOk     = zmin-min(z1,z2)<eps & max(z1,z2)-zmax<eps;

% if one of the condition is not met, return NaN array
edge(~xOk | ~yOk | ~zOk, :) = NaN;
