function [ points ] = intersectLineCylinder( line, cylinder )
%INTERSECTLINECYLINDER compute intersection between a line and a cylinder
%
%   POINTS = intersectLineCylinder(LINE, CYLINDER)
%   Returns intersection points between the line and the cylinder
%   LINE    : [x0 y0 z0  dx dy dz]
%   CLINDER : [xa ya za R xc yc zc]
%   POINTS  : [x1 y1 z1 , x2 y2 z2]
%
%   See also:
%   lines3d
%
%   Author: Daniel Trauth (RWTH)
%   date: 27/01/2009


%% Parameters

% Starting point of the line
c = line(1:3)';

% Direction vector of the line
b = line(4:6)';

% Richtungsvektor q des Zylinder
q = cylinder(1:3)';

% St�tzvektor v des Zylinder
v = cylinder(5:7)';

% Radius of the cylinder
r = cylinder(4);

% Substitution
e = b - (dot(b,q)/dot(q,q))*q;
f = (c-v) - (dot(c-v,q)/dot(q,q))*q;


%% Quadratische Gleichung l�sen um Inkrement zu finde

A = dot(e,e);
B = 2*dot(e,f);
C = dot(f,f) - r^2;

% symbolische l�sung
% 16.01.2009 - es zeigte sich, dass die numerische l�sung sehr viel
% schneller ist!!!
%syms x;
%x = double(solve(A*x^2 + B*x + (C),x));

% numerische l�sung
x1 = (-B + sqrt(B^2-4*A*C))/(2*A);
x2 = (-B - sqrt(B^2-4*A*C))/(2*A);
x = [x1;x2];


%% Estimation of points position

% W�hle kleinstes x, da dieses n�her am Endeffektor ist!
x1 = min((x));

% Point on the line: c + x*b = p
point1 = c + x1*b;

% W�hle anderes x, zur Vollst�ndigkeit!
x2 = max((x));

% Point on the line: c + x*b = p
point2 = c + x2*b;

% Ausgabepunkt
points = [point1' ; point2'];
