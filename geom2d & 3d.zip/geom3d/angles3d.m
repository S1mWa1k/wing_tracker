function angles3d(varargin)
%ANGLES3D Conventions for manipulating angles in 3D
%
%   Contrary to the plane, there is no oriented angle in 3D. Angles are
%   comprised between 0 and PI.
%
%   Spherical angles are defined by 3 angles:
%   - THETA, the colatitude, representing angle with Oz axis
%   - PHI, the azimut, representing angle with Ox axis of horizontal
%       projection of the direction
%   - PSI, which denotes the rotation around the normal direction
%
%   Spherical coordinates can be represented by Theta, phi, and the
%   distance RHO to the origin.
%
%
%   See also
%   cart2sph2, sph2cart2
%   anglePoints3d, angleSort3d, sphericalAngle, randomAngle3d
%   dihedralAngle, polygon3dNormalAngle, createEulerAnglesRotation
%
%
% ------
% Author: David Legland
% e-mail: david.legland@nantes.inra.fr
% Created: 2008-10-13,    using Matlab 7.4.0.287 (R2007a)
% Copyright 2008 INRA - BIA PV Nantes - MIAJ Jouy-en-Josas.
